-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-06-2019 a las 16:47:26
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `boxline`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login`
--

CREATE TABLE `login` (
  `id` int(2) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `contrasena` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `login`
--

INSERT INTO `login` (`id`, `usuario`, `contrasena`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secciones`
--

CREATE TABLE `secciones` (
  `idSec` int(2) NOT NULL,
  `seccion` varchar(30) NOT NULL,
  `personaje` varchar(35) NOT NULL,
  `infografia` varchar(200) NOT NULL,
  `implementos` text NOT NULL,
  `reglas` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `secciones`
--

INSERT INTO `secciones` (`idSec`, `seccion`, `personaje`, `infografia`, `implementos`, `reglas`) VALUES
(1, 'Africa', '', 'img/infografias/infoDambe.jpg', 'Hola editado', 'img/reglas/reglasAfrica.mp4'),
(2, 'Grecia', '', '', 'dfgbhjnmxdtfyghjkdcvij2bfoiebeigneiygng eiufw eofnew fufw ew fkew vdsijg e9vdj', 'img/reglas/reglasGrecia.mp4'),
(3, 'Inglaterra', 'img/personajes/Queensberry.mp4', '', 'b dj k dsnv sjdjhvdw vihwd vih vjhw wehg weh we feuf wef wfh efuh ewhf wfuwef hu fuhefwhf huef wh', 'img/reglas/reglasInglaterra.mp4'),
(4, 'Estados unidos', 'img/personajes/John.mp4', 'img/infografias/infoTecnicas.png', 'nesfimsdvisdn cwe jcwe ociw jkwe c weij wej cwej cwei wej eiwh eih we ewi wei ewndsvnj wieu fwebf wiuh8hy7h7y6g7hunjiyguhu7hyy7hu6gyyhyfgyyhujyhyhiiji9kit6r6r5gy7ju7hu8i8k', 'img/reglas/reglasEEUU.mp4'),
(5, 'Colombia', 'img/personajes/Andres.mp4', 'img/infografias/infoCategorias.png', 'uyvhmhj nvhjn muvhjn guhbjnm fuvhjbnm chgbn cfjgvb sgzfxcresdxfcvcb ncgbn ojm, olkj,m olkj,m hgbn fybvn ghbn fgvbghbv ', 'img/reglas/reglasColombia.mp4');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(2) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `usuario`, `correo`, `fecha`) VALUES
(1, 'Alejandro', 'alejito', 'alejo@gmail.com', '2000-02-02'),
(2, 'santiago', 'fdbjdflkj', 'jlawnflja@gmail.com', '2000-12-20'),
(3, 'kenny', 'kenro', 'kenny@gmail.com', '2000-12-12'),
(4, 'santi', 'sati001', 'santi@gmail.com', '2000-12-22'),
(6, 'juliana', 'jul', 'juli@gmail.com', '2000-12-22');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `secciones`
--
ALTER TABLE `secciones`
  ADD PRIMARY KEY (`idSec`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `login`
--
ALTER TABLE `login`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `secciones`
--
ALTER TABLE `secciones`
  MODIFY `idSec` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
